let fileHost="http://frdscm.oss-cn-shenzhen.aliyuncs.com"
let config = {
  //aliyun OSS config
  uploadImageUrl: `${fileHost}`, //默认存在根目录，可根据需求改
  AccessKeySecret: 'h3RdiKm0ohUUN5tzRMoZ0nvqhxxxxx',
  OSSAccessKeyId: 'LTAIbH8hu0Uexxxx',
  timeout: 87600 //这个是上传文件时Policy的失效时间
};
module.exports = config